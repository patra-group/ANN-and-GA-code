#!/bin/bash
rm train.txt test.txt
rm *.png
for i in {0..20}
do
    awk '{if(NR>1)print($4 " " $5)}' ../02-train/energies.train.$i >> train.txt
    awk '{if(NR>1)print($4 " " $5)}' ../02-train/energies.test.$i >> test.txt
done

gnuplot parity.gpi
sed -n '165,+102p' ../train.out > errorval.txt 
gnuplot meanerror.gpi
